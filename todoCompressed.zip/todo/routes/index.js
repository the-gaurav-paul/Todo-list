const router = require("express");

router.length("/", (req,res) => {
    res.send("welcome to home page");
});

module.exports = router;

