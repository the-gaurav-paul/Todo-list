const express = require("express");
const mongoose = require("mongoose");

const app = express();

mongoose.connect("mongodb://localhost/todo_express",{
    useNewUrlParse: true,
    useUnifiedTopology: true,
});

app.use(express.urlencoded({extended: true}));
app.use(express.static("public"));
app.use("view engine", "ejs");





app.listen(3000, ()=>console.log("Server started"));
